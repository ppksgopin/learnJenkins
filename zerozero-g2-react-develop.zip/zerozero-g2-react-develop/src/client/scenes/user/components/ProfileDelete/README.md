# 刪除使用者

這裡放的是刪除使用者的 Components

## 相關 JIRA

[ZZG2-2438 前台 Web - 會員中心增加「刪除帳號」功能](https://zerozero.atlassian.net/browse/ZZG2-2438)