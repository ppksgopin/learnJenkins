function clearfix(): Object {
  return `
    content: '';
    clear: both;
    display: block;
    visibility: hidden;
    height: 0;
  `
}

export default clearfix
