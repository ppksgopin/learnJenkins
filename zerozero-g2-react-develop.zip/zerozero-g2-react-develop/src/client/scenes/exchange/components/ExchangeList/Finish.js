import React, {Component} from 'react';


class Finish extends Component{

    render() {
        return <div> 兌換清單完成頁 </div>
    }
}

export default Finish;