export const S3ROOT = 'https://s3-ap-northeast-1.amazonaws.com/zerozero-storage';
export const AES_IV = 'zerozero12345678';
export const AES_KEY = 'zerozerosecurity';
