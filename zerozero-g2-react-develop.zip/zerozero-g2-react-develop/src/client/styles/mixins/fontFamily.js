function fontFamily(): Object {
  return `
    font-family: "Noto Sans TC","儷黑 Pro", "LiHei Pro","文泉驛正黑", "WenQuanYi Zen Hei", "微軟正黑體", "Microsoft JhengHei", "新細明體", sans-serif, Arial, Helvetica;
    font-weight:400;
    letter-spacing: 0.125em;
  `
}

export default fontFamily;
