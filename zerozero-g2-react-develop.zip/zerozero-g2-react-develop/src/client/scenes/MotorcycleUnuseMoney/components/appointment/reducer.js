import {combineReducers} from 'redux';

import order from './components/Order/reducer';

export default combineReducers({order})
