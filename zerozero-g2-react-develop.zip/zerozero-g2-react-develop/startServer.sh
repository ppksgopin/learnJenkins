#!/bin/bash

NODE_ENV=production nodemon dist/server/main.js
