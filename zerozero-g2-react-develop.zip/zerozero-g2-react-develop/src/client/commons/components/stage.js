export const ApiRoot = 'https://api-dev.zerozero.com.tw/';
//export const ApiRoot = 'http://localhost:8080/';
//export const ApiRoot = 'https://api-dev.zerozero.com.tw/';


export const SocialCallback = 'https://www-dev.zerozero.com.tw';
