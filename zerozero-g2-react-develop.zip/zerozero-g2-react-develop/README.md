# zerozero-g2-react

### Node.js `v8.6.0`
### npm `v5.3.0`
### yarn `v1.1.0`


## init project
> `yarn`

## start
> `yarn dev:client`
