export const ApiRoot = 'https://api.zerozero.com.tw/';

export const SocialCallback = 'https://www.zerozero.com.tw';