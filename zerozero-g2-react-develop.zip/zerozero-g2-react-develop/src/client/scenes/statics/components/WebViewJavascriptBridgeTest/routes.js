import Loadable from 'loadable-components';

export const WebviewBridge = Loadable(() => import('./components/WebviewBridge'));