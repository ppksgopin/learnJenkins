import moment from 'moment';

moment.locale('tw');

export default moment;
