/**
 * Created by ryan on 2018/3/19.
 */
import Loadable from 'loadable-components';

export const RecycleMap = Loadable(() => import('./components/RecycleMap'));