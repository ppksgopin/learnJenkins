export const completeUrl = path => `https://www.zerozero.com.tw${path}`
