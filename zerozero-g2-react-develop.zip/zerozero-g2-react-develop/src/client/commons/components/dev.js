//export const ApiRoot = 'http://localhost:9090/';
export const ApiRoot = 'https://api-dev.zerozero.com.tw/';
//export const ApiRoot = 'http://192.168.1.106:9090/';


export const SocialCallback = 'https://a861d9236601.ngrok.io';
