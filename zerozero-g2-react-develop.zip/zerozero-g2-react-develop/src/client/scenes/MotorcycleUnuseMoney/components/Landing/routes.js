import Loadable from 'loadable-components' ;

export const Reservation = Loadable(() => import('./components/Reservation'));
